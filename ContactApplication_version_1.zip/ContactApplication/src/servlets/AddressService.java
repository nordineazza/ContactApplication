package servlets;

import java.sql.SQLException;
import java.util.ArrayList;

public class AddressService {

	private JDBC jdbc;
	private String idS;
	private String firstNameS;
	private String streetS;
	private String cityS;
	private String zipS;
	private String countryS;
	
	public AddressService(String id, String street, String city, String zip, String country)
	{
		this.idS = id;
		this.streetS = street;
		this.cityS = city;
		this.zipS = zip;
		this.countryS = country;
	}
	public AddressService(String street, String city, String zip, String country)
	{
		this.streetS = street;
		this.cityS = city;
		this.zipS = zip;
		this.countryS = country;
	}
	public AddressService(boolean i, String value)
	{
		if(i) this.idS = value;
		else this.streetS = value;
		jdbc = new JDBC();
	}
	
	public void CreateAddress() throws SQLException
	{
	//	ContactDAO cdao = new ContactDAO(this.sfirstName, this.slastName, this.smail);
		AddressDAO cdao = new AddressDAO(this.streetS, this.cityS, this.zipS, this.countryS);
		cdao.CreateAddressDAO();
	}
	
	public void updateAddress() throws SQLException
	{
		AddressDAO cdao = new AddressDAO(this.idS,this.streetS, this.cityS, this.zipS, this.countryS);
		cdao.updateAddressDAO();
	}
	
	public void deleteAddress() throws SQLException
	{
		AddressDAO cdao = new AddressDAO(true, this.idS);
		cdao.deleteAddressDAO();
	}
	public ArrayList searchAddress() throws SQLException
	{
		AddressDAO cdao = new AddressDAO(false, this.streetS);
		return cdao.searchAddressDAO();
	}
}
