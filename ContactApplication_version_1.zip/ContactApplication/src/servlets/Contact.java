package servlets;

public class Contact {
	
	private int id;
	private String groupName;
	private String phoneKind;
	private String phoneNumber;
	private String firstName;
	private String lastName;
	private String email;
	private String street;
	private String city;
	private String zip;
	private String country;
	
	public Contact(int id, String firstName, String lastName, String email)
	{
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}
	
	public  ContactGroup getBooks()
	{
		ContactGroup c = new ContactGroup(id,groupName);
		return c;
	}
	
	public ContactGroup setBooks(int id1, String groupName1,String firstName, String lastName, String email,String str, String city, String zip, String cout)
	{
		ContactGroup c = new ContactGroup(id1,groupName1);
		return c;
	}
	
	public PhoneNumber getProfiles()
	{
		PhoneNumber pn = new PhoneNumber(id,phoneKind,phoneNumber);
		return pn;
	}

	public PhoneNumber setProfiles(int id1, String phoneKind1, String phoneNumber1, String firstName, String lastName, String email, String str, String city, String zip, String cout)
	{
		PhoneNumber pn = new PhoneNumber(id1,phoneKind1,phoneNumber1);
		return pn;
	}
	
	public Address getAdd()
	{
		Address a = new Address(street,city,zip,country);
		return a;
	}
	
	public Address setAdd(String str, String c, String zi, String countr)
	{
	  Address a = new Address(str,c,zi,countr);
	  return a;
	}

	@Override
	public String toString() {
		return "Contact [id=" + id + ", groupName=" + groupName + ", phoneKind=" + phoneKind + ", phoneNumber="
				+ phoneNumber + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
	}

	public int getId() {
		return id;
	}

	public String getfirstName() {
		return firstName;
	}

	public String getlastName() {
		return lastName;
	}


	public String getEmail() {
		return email;
	}

	
	

}
