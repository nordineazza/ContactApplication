package servlets;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ContactGroupDAO {

	private String idDAO;
	private JDBC jdbc;
	private String groupContactDAO;
	
	public ContactGroupDAO(String id, String groupName) throws SQLException
	{
		this.idDAO = id;
		this.groupContactDAO = groupName;
		jdbc = new JDBC();
	}
	
	public ContactGroupDAO(String groupName) throws SQLException
	{
		this.groupContactDAO = groupName;
		jdbc = new JDBC();
	}
	
	
	public ContactGroupDAO(boolean i, String value)
	{
		if(i) this.idDAO = value;
		else this.groupContactDAO = value;
		jdbc = new JDBC();
	}
	
	public void CreateContactGroupDAO() throws SQLException
	{
	      System.out.println("Creating statement...");
	      String sql1,sql2,sql3;
	      int rs1,rs2,rs3;
	      ResultSet idrecup;
	      Statement stmt = jdbc.getConnection().createStatement();
	      sql2 = "SELECT MAX(id)as id from contact";
	      idrecup = stmt.executeQuery(sql2);
	      
	      if(idrecup.next())
	      {
	      rs1 = idrecup.getInt(1);
	      
	      sql1 = "INSERT INTO contactgroup (groupId, groupName) VALUES('" + rs1 + "','" + groupContactDAO +"')";
	      rs2 = stmt.executeUpdate(sql1);
	      sql3 = "INSERT INTO books (idGroup, idContact) VALUES('" + rs1 + "','" + rs1 +"')";
	      rs3 = stmt.executeUpdate(sql3);
	      }
	      System.out.println("ContactGroup ajout�e");
	     
	}
	
	public void updateContactGroupDAO() throws SQLException
	{
		System.out.println("Modification a faire en base");
		Statement stmt = jdbc.getConnection().createStatement();
		String sql = "UPDATE contactgroup" +" SET contactgroup.groupName ='"+this.groupContactDAO+"' WHERE contactgroup.groupId ='"+this.idDAO+"'";	
		//System.out.println(sql);
		int modif = stmt.executeUpdate(sql);//exec de la requete
		//System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
	}
	
	public void deleteContactGroupDAO() throws SQLException
	{
		//Il faut l'id pour supprimer un contact
		Statement stmt = jdbc.getConnection().createStatement();
	    int rs = stmt.executeUpdate("DELETE FROM contactgroup WHERE groupId = " + idDAO);
	}
	
	public ArrayList searchContactGroupDAO() throws SQLException
	{
	      System.out.println("D�but de la recherche...");
	      int i = 0;
	      Statement stmt = jdbc.getConnection().createStatement();
	      ResultSet rs = stmt.executeQuery("SELECT distinct * FROM contactgroup WHERE groupName LIKE '%" + this.groupContactDAO + "%'");
	      ArrayList <ContactGroup> mesContactGroup = new ArrayList();
	      //STEP 5: Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	    	  ContactGroup c = new ContactGroup(rs.getInt("groupId"),rs.getString("groupName"));
	    	  mesContactGroup.add(c);
	     }
	     for(ContactGroup c: mesContactGroup)
	    	 System.out.println(c.getGroupId() + c.getGroupName());
		return mesContactGroup;

	}
	
	
	
}
