package servlets;

public class PhoneNumber {
	
	
	private int id;
	private String phoneKind;
	private String phoneNumber;
	private String lastName;
	private String firstName;
	private String email;
	private Contact c;
	
	
	public PhoneNumber(int id, String phonek, String phoneN,Contact c)
	{
		this.id = id;
		this.phoneKind = phonek;
		this.phoneNumber = phoneN;
		this.c = c;
	}
	
	public PhoneNumber(int id, String phonek, String phoneN)
	{
		this.id = id;
		this.phoneKind = phonek;
		this.phoneNumber = phoneN;
	}
	
	public Contact getContact()
	{
		Contact c = new Contact(id,firstName,lastName,email);
		return c;
	}
	public Contact setContact(int id, String firstName, String lastName, String email)
	{
		Contact c = new Contact (id,firstName,lastName,email);
		return c;	
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPhoneKind() {
		return phoneKind;
	}
	public void setPhoneKind(String phoneKind) {
		this.phoneKind = phoneKind;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	

}
