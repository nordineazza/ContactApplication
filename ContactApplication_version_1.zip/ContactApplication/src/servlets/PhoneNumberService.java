package servlets;

import java.sql.SQLException;
import java.util.ArrayList;

public class PhoneNumberService {

	private String sId;
	private String sphoneKind;
	private String sphoneNumber;
	
	
	public PhoneNumberService(String id, String phoneKind, String phoneNumber)
	{
		this.sId = id;
		this.sphoneKind = phoneKind;
		this.sphoneNumber = phoneNumber;
	}
	
	public PhoneNumberService(String phoneKind, String phoneNumber)
	{
		this.sphoneKind = phoneKind;
		this.sphoneNumber = phoneNumber;
	}
	
	
	public PhoneNumberService(boolean i, String value)
	{
		if(i) this.sId = value;
		else  this.sphoneKind = value;
	}
	
	public void CreatePhoneNumber() throws SQLException
	{
	//	ContactDAO cdao = new ContactDAO(this.sfirstName, this.slastName, this.smail);
		PhoneNumberDAO cdao = new PhoneNumberDAO(this.sphoneKind, this.sphoneNumber);
		cdao.CreatePhoneNumberDAO();
	}
	
	public void updatePhoneNumber() throws SQLException
	{
		PhoneNumberDAO cdao = new PhoneNumberDAO(this.sId,this.sphoneKind, this.sphoneNumber);
		cdao.updatePhoneNumberDAO();
	}
	
	public void deletePhoneNumber() throws SQLException
	{
		PhoneNumberDAO cdao = new PhoneNumberDAO(true, this.sId);
		cdao.deletePhoneNumberDAO();
	}
	
	public ArrayList searchPhoneNumber() throws SQLException
	{
		PhoneNumberDAO cdao = new PhoneNumberDAO(false, this.sphoneKind);
		return cdao.searchPhoneNumberDAO();
	}
	

	
}
