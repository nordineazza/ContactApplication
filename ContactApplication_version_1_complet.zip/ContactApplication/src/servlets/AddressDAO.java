package servlets;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AddressDAO {
	private JDBC jdbc;
	private String idDAO;
	private String streetDAO;
	private String cityDAO;
	private String zipDAO;
	private String countryDAO;
	
	public AddressDAO(String id, String street, String city, String zip, String country)
	{
		this.idDAO = id;
		this.streetDAO = street;
		this.cityDAO = city;
		this.zipDAO = zip;
		this.countryDAO = country;
		jdbc = new JDBC();
	}
	
	public AddressDAO(String street, String city, String zip, String country)
	{
		
		this.streetDAO = street;
		this.cityDAO = city;
		this.zipDAO = zip;
		this.countryDAO = country;
		jdbc = new JDBC();
	}
	public AddressDAO(boolean i, String value)
	{
		if(i) this.idDAO = value;
		else this.streetDAO = value;
		jdbc = new JDBC();
	}
	public void CreateAddressDAO() throws SQLException
	{
	      System.out.println("Creating statement...");
	      String sql1,sql2;
	      int rs1;
	      ResultSet idrecup;
	      Statement stmt = jdbc.getConnection().createStatement();
	      sql2 = "SELECT MAX(id)as id from contact";
	      idrecup = stmt.executeQuery(sql2);
	     
	      if(idrecup.next())
	      {
	      rs1 = idrecup.getInt(1);
		  sql1 = "INSERT INTO address(id, idContact, street, city, zip, country) VALUES('" + rs1 + "','" + rs1 + "','" + streetDAO + "','" + cityDAO + "','" + zipDAO +"','" + countryDAO +"')";
	      int rs = stmt.executeUpdate(sql1);
	      }
	      System.out.println("Address ajout�e");
	     
	}
	
	public void updateAddressDAO() throws SQLException
	{
		System.out.println("Modification a faire en base");
		Statement stmt = jdbc.getConnection().createStatement();
		String sql = "UPDATE address SET address.street ='"+this.streetDAO +"',address.zip ='"+this.zipDAO+"',address.city ='"+this.cityDAO+"',address.country ='"+this.countryDAO+"' WHERE idContact ='"+this.idDAO+"'";	
		System.out.println(sql);
		int modif = stmt.executeUpdate(sql);//exec de la requete
		//System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
	}
	
	public void deleteAddressDAO() throws SQLException
	{
		//Il faut l'id pour supprimer un contact
		Statement stmt = jdbc.getConnection().createStatement();
	    int rs = stmt.executeUpdate("DELETE FROM address WHERE idContact = " + idDAO);
	}
	
	public ArrayList searchAddressDAO() throws SQLException
	{
	      System.out.println("D�but de la recherche...");
	      int i = 0;
	      Statement stmt = jdbc.getConnection().createStatement();
	      ResultSet rs = stmt.executeQuery("SELECT * FROM address WHERE street LIKE '%" + this.streetDAO + "%'" + "OR zip LIKE '%" + this.zipDAO + "%'" + "OR city LIKE '%" + this.cityDAO + "%'" +"OR country LIKE '%" + this.countryDAO + "%'");
	      ArrayList <Address> mesAddress = new ArrayList();
	      //STEP 5: Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	    	  Address a = new Address(rs.getInt("id"),rs.getString("street"), rs.getString("city"), rs.getString("zip"), rs.getString("country"));
	    	 mesAddress.add(a);
	     }
	     for(Address a: mesAddress)
	    	 System.out.println(a.getStreet() + a.getCity() + a.getZip() + a.getCountry());
		return mesAddress;

	}
	
	
}

	

