package servlets;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ContactDAO {
	
	private String firstNameDAO; 
	private String lastNameDAO;
	private String mailDAO;
	private String idDAO;
	private JDBC jdbc;
	private String streetDAO;
	private String cityDAO;
	private String zipDAO;
	private String countryDAO;
	private String phoneKindDAO;
	private String phoneNumberDAO;
	private String groupContactDAO;
	private Address Ad;
	
	public ContactDAO(String firstName, String lastName, String mail) throws SQLException
	{
		this.firstNameDAO = firstName;
		this.lastNameDAO = lastName;
		this.mailDAO = mail;
		jdbc = new JDBC();
	}
	
	public ContactDAO(String id, String firstName, String lastName, String mail) throws SQLException
	{
		this.idDAO = id;
		this.firstNameDAO = firstName;
		this.lastNameDAO = lastName;
		this.mailDAO = mail;
		jdbc = new JDBC();
	}
	public ContactDAO(String firstName, String lastName, String mail, String street, String city, String zip, String country, String phoneKind, String phoneNumber, String groupContact) throws SQLException
	{
		this.firstNameDAO = firstName;
		this.lastNameDAO = lastName;
		this.mailDAO = mail;
		this.zipDAO = zip;
		this.streetDAO = street;
		this.cityDAO = city;
		this.countryDAO = country;
		this.phoneKindDAO = phoneKind;
		this.phoneNumberDAO = phoneNumber;
		this.groupContactDAO = groupContact;
		jdbc = new JDBC();
	}
	
	public ContactDAO(String id,String firstName, String lastName, String mail, String street, String city, String zip, String country, String phoneKind, String phoneNumber, String groupContact) throws SQLException
	{
		this.idDAO = id;
		this.firstNameDAO = firstName;
		this.lastNameDAO = lastName;
		this.mailDAO = mail;
		this.zipDAO = zip;
		this.streetDAO = street;
		this.cityDAO = city;
		this.countryDAO = country;
		this.phoneKindDAO = phoneKind;
		this.phoneNumberDAO = phoneNumber;
		this.groupContactDAO = groupContact;
		jdbc = new JDBC();
	}
	
	
	
	public ContactDAO(boolean i, String value)
	{
		if(i) this.idDAO = value;
		else this.firstNameDAO = value;
		jdbc = new JDBC();
	}
	
	public void CreateContactDAO() throws SQLException
	{
	      System.out.println("Creating statement...");
	      String sql1;
	      
	      sql1 = "INSERT INTO contact(firstName, lastName, email) VALUES('" + firstNameDAO + "','" + lastNameDAO + "','" + mailDAO + "')";
	     // sql2 = "SELECT MAX(id)as id from contact";
	      Statement stmt = jdbc.getConnection().createStatement();
	      int rs = stmt.executeUpdate(sql1);
	    // idrecup = stmt.executeQuery(sql2);
	     
	     /* if(idrecup.next())
	      {
	      rs1 = idrecup.getInt(1);
	      sql3 = "INSERT INTO address(id, idContact, street, city, zip, country) VALUES('" + rs1 + "','" + rs1 + "','" + streetDAO + "','" + cityDAO + "','" + zipDAO +"','" + countryDAO +"')";
	      rs2 = stmt.executeUpdate(sql3);
	      
	      sql4 = "INSERT INTO contactgroup (groupId, groupName) VALUES('" + rs1 + "','" + groupContactDAO +"')";
	      rs3 = stmt.executeUpdate(sql4);
	      
	      sql5 = "INSERT INTO phonenumber (id, phoneKind, phoneNumber) VALUES('" + rs1 + "','" + phoneKindDAO + "','" + phoneNumberDAO +"')";
	      rs4 = stmt.executeUpdate(sql5);
	      
	      sql6 = "INSERT INTO books (idGroup, idContact) VALUES('" + rs1 + "','" + rs1 +"')";
	      rs5 = stmt.executeUpdate(sql6);
	      }
	      */
	      System.out.println("Contact ajout�e");
	     
	}
	
	public void updateContactDAO() throws SQLException
	{
		System.out.println("Modification a faire en base");
		Statement stmt = jdbc.getConnection().createStatement();
		String sql = "UPDATE contact" +" SET contact.lastname = '"+this.lastNameDAO+"',contact.firstname ='"+this.firstNameDAO+"',contact.email ='"+this.mailDAO+"' WHERE contact.id ='"+this.idDAO+"'";	
		System.out.println(sql);
		int modif = stmt.executeUpdate(sql);//exec de la requete
		//System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
	}
	
	public void deleteContactDAO() throws SQLException
	{
		//Il faut l'id pour supprimer un contact
		Statement stmt = jdbc.getConnection().createStatement();
	    int rs = stmt.executeUpdate("DELETE FROM contact WHERE id = " + idDAO);
	}
	
	public ArrayList searchContactDAO() throws SQLException
	{
	      System.out.println("D�but de la recherche...");
	    
	      Statement stmt = jdbc.getConnection().createStatement();
	      ResultSet rs = stmt.executeQuery("SELECT distinct * FROM contact,address,phonenumber,contactgroup WHERE firstName LIKE '%" + firstNameDAO + "%'" + "OR lastName LIKE '%" + lastNameDAO + "%'" + " AND contact.id = address.id AND phonenumber.id = address.idContact AND contactgroup.groupId = contact.id ");
	      ArrayList <Contact> mesContacts = new ArrayList();
	      //STEP 5: Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	    	 Contact c = new Contact(rs.getInt("id"),rs.getString("firstName"), rs.getString("lastName"), rs.getString("email"));
	    	 mesContacts.add(c);
	     }
	     for(Contact c: mesContacts)
	    	 System.out.println(c.getfirstName() + c.getBooks().getGroupName());
		return mesContacts;

	}
}
