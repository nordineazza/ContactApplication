package servlets;

public class ContactGroup {
	
	private int groupId;
	private String groupName;
	private String lastName;
	private String firstName;
	private String email;
	private int id;
	
	public ContactGroup(int id, String groupName)
	{
		
		this.groupId = id;
		this.groupName = groupName;
	}
	
	
	@Override
	public String toString() {
		return "ContactGroup [groupId=" + groupId + ", groupName=" + groupName + ", lastName=" + lastName
				+ ", firstName=" + firstName + ", email=" + email + ", id=" + id + "]";
	}


	public Contact getContact()
	{
		Contact c = new Contact(id,firstName,lastName,email);
		return c;
	}
	public Contact setContact(int id, String firstName, String lastName, String email)
	{
		Contact c = new Contact (id,firstName,lastName,email);
		return c;	
	}
	
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	

}
