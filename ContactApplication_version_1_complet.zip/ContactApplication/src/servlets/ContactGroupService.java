package servlets;

import java.sql.SQLException;
import java.util.ArrayList;

public class ContactGroupService {

	private String groupIdS;
	private String groupNameS;
	
	public ContactGroupService(String id, String groupName)
	{
		
		this.groupIdS = id;
		this.groupNameS = groupName;
	}
	
	public ContactGroupService(String groupName)
	{
		
		this.groupNameS = groupName;
	}
	
	public ContactGroupService(boolean i, String value)
	{
		if(i) this.groupIdS = value;
		else  this.groupNameS = value;
	}
	
	public void CreateContactGroup() throws SQLException
	{
	//	ContactDAO cdao = new ContactDAO(this.sfirstName, this.slastName, this.smail);
		ContactGroupDAO cdao = new ContactGroupDAO(this.groupNameS);
		cdao.CreateContactGroupDAO();
	}
	
	public void updateContactGroup() throws SQLException
	{
		ContactGroupDAO cdao = new ContactGroupDAO(this.groupIdS,this.groupNameS);
		cdao.updateContactGroupDAO();
	}
	
	public void deleteContactGroup() throws SQLException
	{
		ContactGroupDAO cdao = new ContactGroupDAO(true, this.groupIdS);
		cdao.deleteContactGroupDAO();
	}
	
	public ArrayList searchContactGroup() throws SQLException
	{
		ContactGroupDAO cdao = new ContactGroupDAO(false, this.groupNameS);
		return cdao.searchContactGroupDAO();
	}
	
	
	
}
