package servlets;

import java.sql.SQLException;
import java.util.ArrayList;

public class ContactService {
	
	private String sfirstName;
	private String slastName;
	private String smail;
	private String sId;
	private String sstreet;
	private String scity;
	private String szip;
	private String scountry;
	private String sphoneKind;
	private String sphoneNumber;
	private String sgroupContact;
	
	public ContactService(String ln, String name, String mail)
	{
		this.sfirstName = ln;
		this.slastName = name;
		this.smail = mail;
	}
	
	public ContactService(String id, String firstname, String name, String mail)
	{
		this.sId = id;
		this.sfirstName = firstname;
		this.slastName = name;
		this.smail = mail;
		
	}
	
	public ContactService(String firstName, String lastName, String mail, String street, String city, String zip, String country, String phoneKind, String phoneNumber, String groupContact)
	{
		this.sfirstName = firstName;
		this.slastName = lastName;
		this.smail = mail;
		this.sstreet= street;
		this.scity = city;
		this.scountry = country;
		this.sphoneKind = phoneKind;
		this.sphoneNumber = phoneNumber;
		this.sgroupContact = groupContact;
	}
	
	public ContactService(String id,String firstName, String lastName, String mail, String street, String city, String zip, String country, String phoneKind, String phoneNumber, String groupContact)
	{
		this.sId = id;
		this.sfirstName = firstName;
		this.slastName = lastName;
		this.smail = mail;
		this.sstreet= street;
		this.scity = city;
		this.scountry = country;
		this.sphoneKind = phoneKind;
		this.sphoneNumber = phoneNumber;
		this.sgroupContact = groupContact;
	}
	
	public ContactService(boolean i, String value)
	{
		if(i) this.sId = value;
		else  this.slastName = value;
	}
	
	public void CreateContact() throws SQLException
	{
	//	ContactDAO cdao = new ContactDAO(this.sfirstName, this.slastName, this.smail);
		ContactDAO cdao = new ContactDAO(this.sfirstName, this.slastName, this.smail);
		cdao.CreateContactDAO();
	}
	
	public void updateContact() throws SQLException
	{
		ContactDAO cdao = new ContactDAO(this.sId, this.sfirstName, this.slastName, this.smail, this.sstreet, this.scity, this.szip, this.scountry, this.sphoneKind, this.sphoneNumber, this.sgroupContact);
		cdao.updateContactDAO();
	}
	
	public void deleteContact() throws SQLException
	{
		ContactDAO cdao = new ContactDAO(true, this.sId);
		cdao.deleteContactDAO();
	}
	
	public ArrayList searchContact() throws SQLException
	{
		ContactDAO cdao = new ContactDAO(false, this.slastName);
		return cdao.searchContactDAO();
	}
	
}
