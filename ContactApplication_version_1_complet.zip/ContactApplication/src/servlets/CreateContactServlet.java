package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateContactServlet
 */
public class CreateContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateContactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String lastname = request.getParameter("lastname");
		String name = request.getParameter("name");
		String mail = request.getParameter("mail");
		String street = request.getParameter("street");
		String city = request.getParameter("city");
		String zip = request.getParameter("zip");
		String country = request.getParameter("country");
		String phoneKind = request.getParameter("phoneKind");
		String phoneNumber = request.getParameter("phoneNumber");
		String groupContact = request.getParameter("groupContact");
		
		
		if(lastname.length() > 0  && name.length() > 0 && mail.length() > 0 && street.length() > 0 && city.length() > 0 && zip.length() > 0 && country.length() > 0 && phoneKind.length() > 0 && phoneNumber.length() > 0 && groupContact.length() > 0)
		{
			ContactService cs;
			AddressService cs1;
			ContactGroupService cs2;
			PhoneNumberService cs3;
			cs = new ContactService(lastname, name, mail);
			cs1 = new AddressService(street,city,zip,country);
			cs2 = new ContactGroupService(groupContact);
			cs3 = new PhoneNumberService(phoneKind,phoneNumber);
			try {
				cs.CreateContact();
				cs1.CreateAddress();
				cs2.CreateContactGroup();
				cs3.CreatePhoneNumber();
				response.sendRedirect("index.html");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			//Si l'utilisateur a renseign� un champs vide, je le redirige vers le menu
			response.sendRedirect("index.html");
			System.out.println("Les champs doivent tous �tre remplis.");
		}
	}

}
