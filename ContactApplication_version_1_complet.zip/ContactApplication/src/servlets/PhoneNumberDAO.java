package servlets;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class PhoneNumberDAO {


	private String idDAO;
	private String phoneKindDAO;
	private String phoneNumberDAO;
	private String lastNameDAO;
	private String firstNameDAO;
	private String emailDAO;
	private Contact cDAO;
	private JDBC jdbc;
	
	
	public PhoneNumberDAO(String id, String phonek, String phoneN)
	{
		this.idDAO = id;
		this.phoneKindDAO = phonek;
		this.phoneNumberDAO = phoneN;
		//this.cDAO = c;
		jdbc = new JDBC();
	}
	public PhoneNumberDAO(String phonek, String phoneN)
	{
		
		this.phoneKindDAO = phonek;
		this.phoneNumberDAO = phoneN;
		jdbc = new JDBC();
	}
	
	public PhoneNumberDAO(boolean i, String value)
	{
		if(i) this.idDAO = value;
		else this.firstNameDAO = value;
		jdbc = new JDBC();
	}
	
	public void CreatePhoneNumberDAO() throws SQLException
	{
	      System.out.println("Creating statement...");
	      String sql1,sql2;
	      int rs1,rs2;
	      ResultSet idrecup;
	      Statement stmt = jdbc.getConnection().createStatement();
	      sql2 = "SELECT MAX(id)as id from contact";
	      idrecup = stmt.executeQuery(sql2);
	      if(idrecup.next())
	      {
	      rs1 = idrecup.getInt(1);
		  sql1 = "INSERT INTO phonenumber (id, phoneKind, phoneNumber) VALUES('" + rs1 + "','" + phoneKindDAO + "','" + phoneNumberDAO +"')";
		  rs2 = stmt.executeUpdate(sql1);
	      }
	      System.out.println("phonenumber ajout�e");
	     
	}
	
	public void updatePhoneNumberDAO() throws SQLException
	{
		System.out.println("Modification a faire en base");
		Statement stmt = jdbc.getConnection().createStatement();
		String sql = "UPDATE phonenumber" +" SET phonenumber.phoneKind ='"+this.phoneKindDAO+"',phonenumber.phoneNumber ='"+this.phoneNumberDAO+"' WHERE phonenumber.id ='"+this.idDAO+"'";	
		//System.out.println(sql);
		int modif = stmt.executeUpdate(sql);//exec de la requete
		//System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
	}
	
	public void deletePhoneNumberDAO() throws SQLException
	{
		//Il faut l'id pour supprimer un contact
		Statement stmt = jdbc.getConnection().createStatement();
	    int rs = stmt.executeUpdate("DELETE FROM phonenumber WHERE id = " + idDAO);
	}
	
	public ArrayList searchPhoneNumberDAO() throws SQLException
	{
	      System.out.println("D�but de la recherche...");
	      int i = 0;
	      Statement stmt = jdbc.getConnection().createStatement();
	      ResultSet rs = stmt.executeQuery("SELECT distinct * FROM phonenumber WHERE id = "+ idDAO);
	      ArrayList <PhoneNumber> mesPhones = new ArrayList();
	      //STEP 5: Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	    	 PhoneNumber p = new PhoneNumber(rs.getInt("id"),rs.getString("phoneKind"), rs.getString("phoneNumber"));
	    	 mesPhones.add(p);
	     }
	     for(PhoneNumber p: mesPhones)
	    	 System.out.println(p.getPhoneKind() + p.getPhoneNumber());
		return mesPhones;

	}
	
	
}
