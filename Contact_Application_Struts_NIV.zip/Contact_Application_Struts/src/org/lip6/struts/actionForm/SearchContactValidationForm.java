package org.lip6.struts.actionForm;




import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.lip6.struts.domain.Contact;

public class SearchContactValidationForm  extends ActionForm{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
	private ArrayList<Contact> lcontact;
	private String erreur;
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
	    this.firstName=null;
	}
	
	 /**
	   * @return First Name
	   */
	  public String getFirstName() {
	    return firstName;
	  }

	  /**
	   * @param string Sets the First Name
	   */
	  public void setFirstName(String string) {
	    firstName = string;
	  }
	  
	//arraylist pour recuperer et afficher les contacts  
	public ArrayList<Contact> getLcontact() {
		return lcontact;
	}

	public void setLcontact(ArrayList<Contact> lcontact) {
		this.lcontact = lcontact;
	}

	
	public String getErreur() {
		return erreur;
	}

	public void setErreur(String erreur) {
		this.erreur = erreur;
	}

	public ActionErrors validate( 
	      ActionMapping mapping, HttpServletRequest request ) {
	      ActionErrors errors = new ActionErrors();
	      
	      if( getFirstName()== null || getFirstName().length() < 1 ) {
	        errors.add("first name",new ActionMessage("creation.fn.error.required"));
	      }
	      return errors;
	  }

}
