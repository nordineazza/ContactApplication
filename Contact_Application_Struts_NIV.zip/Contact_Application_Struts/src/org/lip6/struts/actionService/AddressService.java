package org.lip6.struts.actionService;

import java.sql.SQLException;

import org.lip6.struts.domain.*;

public class AddressService {
	
	private String idS;
	private String streetS;
	private String cityS;
	private String zipS;
	private String countryS;

	public AddressService(String id, String street, String city, String zip, String country)
	{
		this.idS = id;
		this.streetS = street;
		this.cityS = city;
		this.countryS = country;
	}
	
	public AddressService(String street, String city, String zip, String country)
	{
		
		this.streetS = street;
		this.cityS = city;
		this.countryS = country;
	}
	
	
	public AddressService(String id)
	{
		this.idS = id;
	}
	
	
	
	public String CreateAddress() throws SQLException
	{
	
		DAOAddress cdao = new DAOAddress();
		return cdao.addAddress(streetS, cityS, zipS, countryS);
	}
	
	
	public void updateAddress() throws SQLException
	{
		DAOAddress cdao = new DAOAddress();
		cdao.modifyAddress(idS, streetS, cityS, zipS, countryS);
	}
	
	public String deleteAddress() throws SQLException
	{
		DAOAddress cdao = new DAOAddress();
		return cdao.suppAddress(idS);
	}
	
}
