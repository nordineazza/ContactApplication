package org.lip6.struts.actionService;

import java.sql.SQLException;

import org.lip6.struts.domain.*;

public class ContactGroupService {

	private String groupIdS;
	private String groupNameS;
	
	
	
	public ContactGroupService(String id, String name)
	{
		this.groupIdS = id;
		this.groupNameS = name;
	}
	
	public ContactGroupService(String name)
	{

		this.groupNameS = name;
	}
	
	
	public String CreateContactGroup() throws SQLException
	{

		DAOContactGroup cdao = new DAOContactGroup();
		return cdao.addGroup(groupNameS);
	}
	
	public void updateContactGroup() throws SQLException
	{
		DAOContactGroup cdao = new DAOContactGroup();
		cdao.modifyContactGroup(groupIdS, groupNameS);
	}
	
	public String deleteContactGroup() throws SQLException
	{
		DAOContactGroup cdao = new DAOContactGroup();
		return cdao.suppContactGroup(groupIdS);
	}
	
	
	
	
}
