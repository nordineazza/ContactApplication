package org.lip6.struts.actionService;

import java.sql.SQLException;

import org.lip6.struts.actionForm.SearchContactValidationForm;
import org.lip6.struts.domain.*;

public class ContactService {
	
	private String sfirstName;
	private String slastName;
	private String smail;
	private String sId;

	
	public ContactService(String first,String name,String mail)
	{
		this.sfirstName = first;
		this.slastName = name;
		this.smail = mail;
		
	}
	
	public ContactService(String id)
	{
		this.sId = id;
		
	}
	
	public String CreateContact() throws SQLException
	{

		DAOContact cdao = new DAOContact();
		return cdao.addContact(sfirstName, slastName, smail);
	}
	
	public void updateContact() throws SQLException
	{
		DAOContact cdao = new DAOContact();
		cdao.modifyContact(sId, sfirstName, slastName, smail);
	}
	
	public String deleteContact() throws SQLException
	{
		DAOContact cdao = new DAOContact();
		return cdao.suppContact(sId);
	}
	
	public SearchContactValidationForm searchContact() throws SQLException
	{
		DAOContact cdao = new DAOContact();
		return cdao.fetchContact(sfirstName);
	}
	
}
