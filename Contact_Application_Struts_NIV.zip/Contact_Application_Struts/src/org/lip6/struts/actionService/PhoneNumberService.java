package org.lip6.struts.actionService;

import java.sql.SQLException;
import java.util.ArrayList;

import org.lip6.struts.domain.*;

public class PhoneNumberService {

	private String sId;
	private String sphoneKind;
	private String sphoneNumber;
	
	public PhoneNumberService(String id, String phoneK, String phoneN)
	{
		this.sId = id;
		this.sphoneKind = phoneK;
		this.sphoneNumber = phoneN;
	}
	
	public PhoneNumberService( String phoneK, String phoneN)
	{
		
		this.sphoneKind = phoneK;
		this.sphoneNumber = phoneN;
	}
	
	public PhoneNumberService(String id)
	{
		this.sId = id;
	}
	
	
	public String CreatePhoneNumber() throws SQLException
	{
		DAOPhoneNumber cdao = new DAOPhoneNumber();
		return cdao.addPhone(sphoneKind, sphoneNumber);
	}
	
	public void updatePhoneNumber() throws SQLException
	{
		DAOPhoneNumber cdao = new DAOPhoneNumber();
		cdao.modifyPhone(sId, sphoneKind, sphoneNumber);
	}
	
	public String delete() throws SQLException
	{
		DAOPhoneNumber cdao = new DAOPhoneNumber();
		return cdao.suppPhone(sId);
	}
	
	

	
}
