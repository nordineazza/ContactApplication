package org.lip6.struts.domain;

public class ContactCreation {
	
	
	

}
