package org.lip6.struts.domain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DAOAddress {

private JDBC jdbc;

	public String addAddress(final String street, final String city, final String zip, final String country) {
			
		try {
				  jdbc=new JDBC();
				  System.out.println("Creating statement...");
			      String sql1,sql2;
			      int rs1;
			      ResultSet idrecup;
			      Statement stmt = jdbc.getConnection().createStatement();
			      sql2 = "SELECT MAX(id)as id from contact";
			      idrecup = stmt.executeQuery(sql2);
			     
			      if(idrecup.next())
			      {
			      rs1 = idrecup.getInt(1);
				  sql1 = "INSERT INTO address(id, idContact, street, city, zip, country) VALUES('" + rs1 + "','" + rs1 + "','" + street + "','" + city + "','" + zip +"','" + country +"')";
			      int rs = stmt.executeUpdate(sql1);
			      }
			      System.out.println("Address ajout�e");
				
				return null;
			} catch (SQLException e) {

				return "SQLException : " + e.getMessage();
				
			}
		}
	
	public String suppAddress(final String id) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Suppression statement...");
		      String sql1;
		      sql1 = "DELETE FROM address WHERE id = " + id;
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("Address supprime");
		      return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	public String modifyAddress(final String id, final String street, final String city, final String zip, final String country) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Modification a faire en base");
			  Statement stmt = jdbc.getConnection().createStatement();
			  String sql = "UPDATE address SET address.street ='"+street +"',address.zip ='"+zip+"',address.city ='"+city+"',address.country ='"+country+"' WHERE idContact ='"+id+"'";	
			  System.out.println(sql);
			  int modif = stmt.executeUpdate(sql);//exec de la requete
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
		
	}

	
