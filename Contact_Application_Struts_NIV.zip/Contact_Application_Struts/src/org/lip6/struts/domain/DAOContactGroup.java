package org.lip6.struts.domain;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DAOContactGroup {

	
	private JDBC jdbc;
	public String addGroup(final String groupContact) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Creating statement...");
		      String sql1,sql2,sql3,sql4;
		      int rs1,rs2,rs3,rs4;
		      ResultSet idrecup,idrecup1;
		      Statement stmt = jdbc.getConnection().createStatement();
		      sql2 = "SELECT MAX(id)as id from contact";
		      idrecup = stmt.executeQuery(sql2);
		      
		      
		      sql4 = "SELECT * from contactgroup where groupName = " + groupContact;
		      idrecup1 = stmt.executeQuery(sql4);
		      
		  
		 
		      if(idrecup.next() && !idrecup1.next())
		      {
		      rs1 = idrecup.getInt(1);
		      
		    	 sql1 = "INSERT INTO contactgroup (groupName) VALUES('" + groupContact +"')";
			     rs2 = stmt.executeUpdate(sql1);
		      //sql3 = "INSERT INTO books (idGroup, idContact) VALUES('" + rs4 + "','" + rs1 +"')";
		      //rs3 = stmt.executeUpdate(sql3);
		      }
		       
			  
			  
			     // sql3 = "INSERT INTO books (idContact) VALUES('"+ rs1 +"')";
			     // rs3 = stmt.executeUpdate(sql3);
		    	 
		     
		      System.out.println("ContactGroup et books ajout�e");
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	public String suppContactGroup(final String id) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Suppression statement...");
		      String sql1;
		      sql1 = "DELETE FROM contactgroup WHERE id = " + id;
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("ContactGroup, books supprime");
		      return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	public String modifyContactGroup(final String id, final String groupContact) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Modification a faire en base");
			  Statement stmt = jdbc.getConnection().createStatement();
			  String sql = "UPDATE contactgroup" +" SET contactgroup.groupName ='"+groupContact+"' WHERE contactgroup.groupId ='"+id+"'";	
			  //System.out.println(sql);
			  int modif = stmt.executeUpdate(sql);//exec de la requete
			  //System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	
}
