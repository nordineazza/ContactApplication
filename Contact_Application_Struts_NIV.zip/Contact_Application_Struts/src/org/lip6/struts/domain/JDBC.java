package org.lip6.struts.domain;


import java.sql.DriverManager;  // gestion des pilotes
import java.sql.Connection;     // une connexion � la BD
import java.sql.Statement;      // une instruction 
import java.sql.ResultSet;      // un r�sultat (lignes/colonnes)
import java.sql.SQLException;   // une erreur

public class JDBC {
	
	private Connection conn;
	
	public JDBC()
	{
		try {
			try {
				loadDriver();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.conn = newConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void loadDriver() throws ClassNotFoundException {
	    Class.forName("com.mysql.jdbc.Driver");
	}

	public Connection newConnection() throws SQLException {
	    final String url = "jdbc:mysql://localhost/contact";
	    Connection conn = DriverManager.getConnection(url, "root", "root");
	    return conn;
	}
	
	public Connection getConnection() throws SQLException
	{
		return newConnection();
	}
	
	public void test() throws SQLException
	{
	      System.out.println("Creating statement...");
	      Statement stmt = conn.createStatement();
	      String sql;
	      sql = "SELECT * FROM contact";
	      ResultSet rs = stmt.executeQuery(sql);
	      //STEP 5: Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	         String firstName  = rs.getString("firstName");
	         String lastName = rs.getString("lastName");
	         String email = rs.getString("email");
	         String id = rs.getString("id");
	         System.out.println("Bonjour, " + firstName + " " + lastName);
	     }
	}


}
