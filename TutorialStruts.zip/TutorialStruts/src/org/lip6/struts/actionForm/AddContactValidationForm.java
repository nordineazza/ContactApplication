package org.lip6.struts.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
public class AddContactValidationForm extends ActionForm {
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id=0;   
	  private String firstName=null;
	  private String lastName=null;
	  private String email=null;
	  private String street=null;
	  private String zip=null;
	  private String phoneNumber=null;
	  private String phoneKind=null;
	  private String country=null;
	  private String contactGroup=null;
	  private String city=null;
	  
	  /**
	   * @return First Name
	   */
	  public String getStreet() {
	    return street;
	  }
	  
	  
	  
	  /**
	   * @return Zip
	   */
	  public String getZip() {
	    return zip;
	  }
	  
	  
	  /**
	   * @return Phone Number
	   */
	  public String getPhoneNumber() {
	    return phoneNumber;
	  }
	  
	  /**
	   * @return Phone Kind
	   */
	  public String getPhoneKind() {
	    return phoneKind;
	  }
	  
	  /**
	   * @return Country
	   */
	  public String getCountry() {
	    return country;
	  }
	  
	  /**
	   * @return Contact group
	   */
	  public String getContactGroup() {
	    return contactGroup;
	  }
	  
	/**
	   * @return Email
	   */
	  public String getEmail() {
	    return email;
	  }

	  /**
	   * @return First Name
	   */
	  public String getFirstName() {
	    return firstName;
	  }

	  /** 
	   * @return Last name
	   */
	  public String getLastName() {
	    return lastName;
	  }

	  
	  
	  public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	/**
	   * @param string Sets the Email
	   */
	  public void setEmail(String string) {
	    email = string;
	  }

	  /**
	   * @param string Sets the First Name
	   */
	  public void setFirstName(String string) {
	    firstName = string;
	  }

	  /**
	   * @param string sets the Last Name
	   */
	  public void setLastName(String string) {
	    lastName = string;
	  }

	  
	  
	  public void setStreet(String street) {
		this.street = street;
	}



	public void setZip(String zip) {
		this.zip = zip;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	public void setPhoneKind(String phoneKind) {
		this.phoneKind = phoneKind;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public void setContactGroup(String contactGroup) {
		this.contactGroup = contactGroup;
	}



	/**
	   * @return ID Returns ID
	   */
	  public long getId() {
	    return id;
	  }

	  /**
	   * @param l Sets the ID
	   */
	  public void setId(long l) {
	    id = l;
	  }
	  
	  public void reset(ActionMapping mapping, HttpServletRequest request) {
		  	this.id=0;
		    this.firstName=null;
		    this.lastName=null;
		    this.email=null;
	  }
	  
	  public ActionErrors validate( 
		      ActionMapping mapping, HttpServletRequest request ) {
		      ActionErrors errors = new ActionErrors();
		      
		      if( getFirstName()== null || getFirstName().length() < 1 ) {
		        errors.add("first name",new ActionMessage("creation.fn.error.required"));
		      }
		      if( getLastName()== null || getLastName().length() < 1 ) {
		        errors.add("last name",new ActionMessage("creation.ln.error.required"));
		      }
		      if( getEmail() == null || getEmail().length() < 1 ) {
		        errors.add("email", new ActionMessage("creation.email.error.required"));
		      }
		      return errors;
		  }
}
