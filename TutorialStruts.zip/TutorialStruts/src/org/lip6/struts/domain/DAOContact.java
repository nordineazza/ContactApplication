package org.lip6.struts.domain;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.lip6.struts.actionForm.SearchContactValidationForm;

public class DAOContact {
private JDBC jdbc;
	
	

	public String addContact(final String firstName, final String lastName, final String email) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Creating statement...");
		      String sql1;
		      sql1 = "INSERT INTO contact(firstName, lastName, email) VALUES('" + firstName + "','" + lastName + "','" + email + "')";
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("Contact ajoute");
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	
	public SearchContactValidationForm fetchContact(final String firstName){
		final SearchContactValidationForm lsearchForm=new SearchContactValidationForm();
		try {
			 jdbc=new JDBC();
			 String sql1;
			 sql1="SELECT distinct * FROM contact WHERE firstName = '" + firstName + "'";
			 System.out.println("recherche...");
			 Statement stmt = jdbc.getConnection().createStatement();
			 ResultSet rs = stmt.executeQuery(sql1);
			 ArrayList <Contact> mesContacts = new ArrayList<Contact>();
		      //STEP 5: Extract data from result set
		      while(rs.next()){
		         //Retrieve by column name		    	 
		    	 Contact c = new Contact(rs.getInt("id"), rs.getString("lastName"), rs.getString("firstName"), rs.getString("email"));
		    	 mesContacts.add(c);
		     }
//		     for(Contact c: mesContacts)
//		    	 System.out.println(c.getFirstName());
//			return null;
		      lsearchForm.setLcontact(mesContacts);
			} catch (SQLException e) {

				lsearchForm.setErreur("SQLException : " + e.getMessage());
			}
		return lsearchForm;
	}
	
	public String suppContact(final String id) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Suppression statement...");
		      String sql1;
		      sql1 = "DELETE FROM contact WHERE id = " + id;
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("Contact supprime");
		      return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	public String modifyContact(final String id, final String firstName, final String lastName, final String email) {
		try {
			  jdbc=new JDBC();
			  	System.out.println("Modification a faire en base");
				Statement stmt = jdbc.getConnection().createStatement();
				String sql = "UPDATE contact" +" SET contact.lastName = '"+lastName+"',contact.firstName ='"+firstName+"',contact.email ='"+email+"' WHERE contact.id ='"+id+"'";	
				System.out.println(sql);
				int modif = stmt.executeUpdate(sql);//exec de la requete
				System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	

}	