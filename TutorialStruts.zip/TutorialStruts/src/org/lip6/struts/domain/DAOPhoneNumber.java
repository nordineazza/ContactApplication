package org.lip6.struts.domain;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DAOPhoneNumber {

	
	private JDBC jdbc;
	public String addPhone(final String phoneKind, final String phoneNumber) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Creating statement...");
		      String sql1,sql2;
		      int rs1,rs2;
		      ResultSet idrecup;
		      Statement stmt = jdbc.getConnection().createStatement();
		      sql2 = "SELECT MAX(id)as id from contact";
		      idrecup = stmt.executeQuery(sql2);
		      if(idrecup.next())
		      {
		      rs1 = idrecup.getInt(1);
			  sql1 = "INSERT INTO phonenumber (id, phoneKind, phoneNumber) VALUES('" + rs1 + "','" + phoneKind + "','" + phoneNumber +"')";
			  rs2 = stmt.executeUpdate(sql1);
		      }
		      System.out.println("phonenumber ajout�e");
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	public String suppPhone(final String id) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Suppression statement...");
		      String sql1;
		      sql1 = "DELETE FROM phonenumber WHERE id = " + id;
		      Statement stmt = jdbc.getConnection().createStatement();
		      int rs = stmt.executeUpdate(sql1);
		      System.out.println("Phone Number supprime");
		      return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	public String modifyPhone(final String id,final String phoneKind, final String phoneNumber) {
		try {
			  jdbc=new JDBC();
			  System.out.println("Modification a faire en base");
			  Statement stmt = jdbc.getConnection().createStatement();
			  String sql = "UPDATE phonenumber" +" SET phonenumber.phoneKind ='"+phoneKind+"',phonenumber.phoneNumber ='"+phoneNumber+"' WHERE phonenumber.id ='"+id+"'";	
			  //System.out.println(sql);
			  int modif = stmt.executeUpdate(sql);//exec de la requete
			  //System.out.println("nb de lignes mises a jour=" + modif);//affiche le nb de lignes mises a jour
			
			return null;
		} catch (SQLException e) {

			return "SQLException : " + e.getMessage();
			
		}
	}
	
	
}
