package org.lip6.struts.servletAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.lip6.struts.actionForm.AddContactValidationForm;
import org.lip6.struts.domain.DAOAddress;
import org.lip6.struts.domain.DAOContact;
import org.lip6.struts.domain.DAOContactGroup;
import org.lip6.struts.domain.DAOPhoneNumber;

public class AddContactAction extends Action {

	
	public ActionForward execute(final ActionMapping pMapping,
			ActionForm pForm, final HttpServletRequest pRequest,
			final HttpServletResponse pResponse) {
		
		final AddContactValidationForm lForm=(AddContactValidationForm)pForm;

		
		final String firstName = lForm.getFirstName();
		final String lastName = lForm.getLastName();
		final String email = lForm.getEmail();
		final String street=lForm.getStreet();
		final String country=lForm.getCountry();
		final String zip=lForm.getZip();
		final String city=lForm.getCity();
		final String phoneNumber=lForm.getPhoneNumber();
		final String phoneKind=lForm.getPhoneKind();
		final String contactGroup=lForm.getContactGroup();
		

		// create a new Contact
		final DAOContact lDAOContact = new DAOContact();
		String lError = lDAOContact.addContact(firstName, lastName, email);
		//create a new Address
		final DAOAddress lDAOAddress = new DAOAddress();
		lError = lDAOAddress.addAddress(street, city, zip, country);
		//create a new PhoneNumber
		final DAOPhoneNumber lDAOPhone = new DAOPhoneNumber();
		lError = lDAOPhone.addPhone(phoneKind,phoneNumber);
		//create a contact group
		final DAOContactGroup lDAOContactGroup = new DAOContactGroup();  
		lError = lDAOContactGroup.addGroup(contactGroup);
		
		if(lError == null) {
			// if no exception is raised,  forward "success"
			return pMapping.findForward("addsuccess");
		}
		else {
			// If any exception, return the "error" forward
			return pMapping.findForward("error");
		}
		

		
		
	}
}
