package org.lip6.struts.servletAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.lip6.struts.actionForm.AddContactValidationForm;
import org.lip6.struts.domain.DAOAddress;
import org.lip6.struts.domain.DAOContact;
import org.lip6.struts.domain.DAOContactGroup;
import org.lip6.struts.domain.DAOPhoneNumber;

public class SuppContactAction extends Action {

	
	public ActionForward execute(final ActionMapping pMapping,
			ActionForm pForm, final HttpServletRequest pRequest,
			final HttpServletResponse pResponse) {

		String id1=pRequest.getParameter("id");
		//delete a Contact
		final DAOContact lDAOContact = new DAOContact();
		String lError = lDAOContact.suppContact(id1);//supprime de la table contact
		final DAOAddress lDAOAddress = new DAOAddress();
		lError = lDAOAddress.suppAddress(id1);
		//create a new PhoneNumber
		final DAOPhoneNumber lDAOPhone = new DAOPhoneNumber();
		lError = lDAOPhone.suppPhone(id1);
		//create a contact group
		final DAOContactGroup lDAOContactGroup = new DAOContactGroup();  
		lError = lDAOContactGroup.suppContactGroup(id1);
		
		return null;

		
		
	}
}
